<?php
	session_start();
	$_SESSION = array();
	session_destroy();
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Тестирование</title>
 		<link rel="stylesheet" type="text/css" href="/style.css">
	</head>
  <body>
    <p class="main_header">Система тестирования "Take the test"</p> 
    <p class="main_text"> Добро пожаловать в систему онлайн-тестирования "Take the test".Система тестирования "Take the test" разработана для создания тестов и проведения тестирования зарегистрированных пользователей. Тестирующая система содержит большой банк тестов по различным направлениям. Система онлайн тестирования имеет следующие возможности:
    <ul class="spisok">
      <li>создание и удаление тестов,</li>
      <li>автоматизированная проверка выполненных заданий</li> 
    </ul>
    <p class=main_text>Для входа в систему необходимо ввести логин и пароль в соответствующие поля:</p>
    <form method="post" action="/scripts/auth.php">
      <p class=log_pass> ВВЕДИТЕ ЛОГИН </BR>
        <input maxlength="25" size="30" value="" name="login"></br></br>
        ВВЕДИТЕ ПАРОЛЬ </BR>
        <input type="password" maxlength="25" size="30" name="passwd"></br></br>
        <input type="submit" value="ВОЙТИ В СИСТЕМУ">
      </p>
    </form>
  </body>
 </html>
