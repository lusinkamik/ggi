<?php
	session_start();
	if (!isset($_SESSION['login']))
	{
		Header("Location: /index.php");
	}
	require_once("queries.php");
  // задаем набор символов по умолчанию
  if (!mysqli_set_charset($link, "utf8"))
  {
 		die("Ошибка при загрузке набора UTF8: " . mysqli_error($link) . "\n");
  }
  // фильтрация данных
 	$corr_answer = mysqli_real_escape_string($link, $_POST['radio']);
	// проверка на пустоту
	if (empty($corr_answer)) die();

	if (!isset($_SESSION['trueanswer'])) die("не указан правильный ответ для текущего вопроса в БД");

	if ($corr_answer == $_SESSION['trueanswer']) $_SESSION['rating'] += 1;

	if (isset($_SESSION['end'])) Header("Location: result.php");
	else Header("Location: take_the_test.php");
?>
