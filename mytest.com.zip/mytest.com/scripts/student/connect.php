<?php
	$dblocation = "localhost";
	$dbname     = "mytest";
	$dblogin    = "student";
	$dbpasswd   = "p@ssw0rd";
	$link       = mysqli_connect($dblocation, $dblogin, $dbpasswd, $dbname);
	if (!$link)
	{
		die('Ошибка подключения (' . mysqli_connect_errno() . ') ' . mysqli_connect_error());
	}
?>
