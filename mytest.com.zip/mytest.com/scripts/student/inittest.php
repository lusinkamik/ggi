<?php
	session_start();
	if (!isset($_SESSION['login']))
	{
		Header("Location: /index.php");
	}
	require_once("queries.php");
  // задаем набор символов по умолчанию
  if (!mysqli_set_charset($link, "utf8"))
  {
 		die("Ошибка при загрузке набора UTF8: " . mysqli_error($link) . "\n");
  }
  // фильтрация данных
 	$theme = mysqli_real_escape_string($link, $_POST['theme']);
	// проверка на пустоту
	if (empty($theme)) die();

	// извлекаем идентификатор теста по теме теста
	$query = get_id_test_by_theme($link, $theme);
	$row = mysqli_fetch_row($query);
	$id_test = $row[0];
	
	// помещаем идентификатор теста в сессию
	$_SESSION['id_test'] = $id_test;
	
	// СОЗДАЁМ СЕССИОННЫЕ ПЕРЕМЕННЫЕ ДЛЯ ХРАНЕНИЯ НОМЕРА ВОПРОСА
	$_SESSION['numcurrquest'] = 0;  // номер текущего вопроса
	$_SESSION['idprevquest'] = -1;  // идентификатор предыдущего вопроса

	// узнаем идентификатор последнего вопроса в данном тесте
	$query = get_id_lastquest_by_id_test($link, $id_test);
	$row = mysqli_fetch_row($query);
	$_SESSION['idlastquest'] = $row[0];
	
	// баллы пользователя
	$_SESSION['rating'] = 0;

	// уходим на take_the_test.php
	Header("Location: take_the_test.php");
?>
