<?php
  session_start();
  if (!isset($_SESSION['login']))
  {
    Header("Location: /index.php");
  }
	$_SESSION['numcurrquest'] += 1; // номер текущего вопроса инкрементируем
?>

<!DOCTYPE html>
<html>
	<head>
		<title> Тестирование </title>	
		<link rel="stylesheet" type="text/css" href="/style.css">
 	</head>
	<body> 
  	<p class="main_header">Система тестирования "Take the test"</p>
		<table width="100%" border="0">
 			<tr>
				<td><p class="main_text"><?php echo("Режим прохождения теста:"); ?></p></td>
				<td><a id="logout" href="logout.php">Выйти</td>
			</tr>
		</table>
  	<form method="post" action="analyze.php">
  	<table border="0" cellspacing="7" cellpadding="0">
    	<tr>
      	<td class="spisok">Вопрос № <?php echo($_SESSION['numcurrquest'])?>:</td>
				<?php
					require_once("queries.php");
					$query = get_id_and_question_by_id_test($link, $_SESSION['id_test'], $_SESSION['idprevquest']);
					$row = mysqli_fetch_row($query);
					if ($row[0] == $_SESSION['idlastquest']) $_SESSION['end'] = True;
					$_SESSION['idprevquest'] = $row[0];
				?>
      	<td><input type="text" name="question" maxlength="1024" size="120" value="<?php echo($row[1])?>"></input></td>
    	</tr>
				<?php
					$idprevanswer  = -1;
					$numcurranswer =  1;
					while ($numcurranswer <= 4)
					{
						$query = get_id_and_answer_and_trueanswer_by_id_question($link, $_SESSION['idprevquest'], $idprevanswer);
						$row = mysqli_fetch_row($query);
						$idprevanswer = $row[0]; // перезаписываем идентификатор предыдущего ответа
						echo("<tr>");
						if ($numcurranswer == 1)
    					echo("<td align='right'><input type='radio' name='radio' value='$numcurranswer' checked='checked'></input></td>");
						else
    					echo("<td align='right'><input type='radio' name='radio' value='$numcurranswer'></input></td>");
      			echo("<td><input type='text' name='$numcurranswer' maxlength='1024' size='50' value='$row[1]'></input></td>");
						echo("</tr>");
						if ($row[2] == "1") $_SESSION['trueanswer'] = $numcurranswer;
						$numcurranswer++;
					}
				?>
   	</table></br>
   <table border="0" cellspacing="7" cellpadding="0" align="center">
  	<tr>
    	<td width="50"><input type="submit" name="submit" value="Следующий вопрос"></input></td>
  	</tr>
  	</table>
  </form>
 </body>
</html>
