<?php
  session_start();
  if (!isset($_SESSION['login']))
  {
    Header("Location: /index.php");
  }
	
	require_once("queries.php");
  // задаем набор символов по умолчанию
  if (!mysqli_set_charset($link, "utf8"))
  {
 		die("Ошибка при загрузке набора UTF8: " . mysqli_error($link) . "\n");
  }
  // фильтрация данных
 	$category = mysqli_real_escape_string($link, $_POST['category']);
	// проверка на пустоту вводимых данных
	if (empty($category)) die();
?>
<!DOCTYPE html>
<html>
	<head>
		<title> Тестирование </title>
		<link rel="stylesheet" type="text/css" href="/style.css">
 	</head>
	<body> 
  	<p class="main_header">Система тестирования "Take the test"</p>
 		<p class="main_text"><?php echo("Выберите тест:"); ?></p>
  	<form method="post" action="inittest.php">
  	<table border="0" cellspacing="7" cellpadding="0"> 
    	<tr> 
      	<td class="spisok">Выберите тест: </td>
      	<td>
					<?php
						$query = get_id_category_by_category($link, $category);
						$row = mysqli_fetch_row($query);
						$id_category = $row[0];
						$query = get_tests($link, $id_category);
						echo "<select name=\"theme\">";
						while (list($theme) = mysqli_fetch_row($query))
						{
							echo "<option>$theme</option>";
						}
						echo "</select>";
						// помещаем в сессию идентификатор категории теста
						$_SESSION['id_category'] = $id_category;
					?>
				</td>
    	</tr>
   	</table></br>
   <table border="0" cellspacing="7" cellpadding="0" align="center"> 
  	<tr>
     	<td width="50"><input type="submit" name="submit" value="Начать"></input></td>
  	</tr>
  	</table>
  </form>
 </body>
</html>
