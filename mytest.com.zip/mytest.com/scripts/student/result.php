<?php
  session_start();
  if (!isset($_SESSION['login']))
  {
    Header("Location: /index.php");
  }

	require_once("queries.php");
	
	$query = numquestions_by_id_test($link, $_SESSION['id_test']);
	$row = mysqli_fetch_row($query);
	$numquestions = (float) $row[0];
?>
<!DOCTYPE html>
<html>
	<head>
		<title> Тестирование </title>
		<link rel="stylesheet" type="text/css" href="/style.css">
 	</head>
	<body> 
  	<p class="main_header">Система тестирования "Take the test"</p>
 		<p class="main_text"><?php echo("Процент выполнения теста, ".$_SESSION['login'].", составляет: "); ?></p>
		<p class="main_text"><?php echo(((float) $_SESSION['rating'])/$numquestions * 100) . "%"?></p>
  </form>
 </body>
</html>
