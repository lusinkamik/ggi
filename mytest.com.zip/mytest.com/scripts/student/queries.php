<?php
	// подключение к БД от имени teacher
	require_once("connect.php");
	// задаем глобально кодировку для БД
	mysqli_query($link, 'SET NAMES utf8');
	// выбрать все категории
	function get_categories($link)
	{
		$query = "SELECT name FROM categories";
		$result = mysqli_query($link, $query) or die(mysqli_error($link));
		return $result;
	}

	// выбрать все тесты по данной категории
	function get_tests($link, $id_category)
	{
		$query = "SELECT theme FROM	tests WHERE id_category='$id_category'";
		$result = mysqli_query($link, $query) or die(mysqli_error($link));
		return $result;
	}

	// извлечь номер категории теста по категории теста
	function get_id_category_by_category($link, $category)
	{
		$query = "SELECT (id_category) FROM categories WHERE name='$category'";
		$result = mysqli_query($link, $query) or die(mysqli_error($link));
		return $result;
	}

	// извлчеь номер теста по теме теста
	function get_id_test_by_theme($link, $theme)
	{
		$query = "SELECT (id_test) FROM tests WHERE theme='$theme'";
		$result  = mysqli_query($link, $query) or die(mysqli_error($link));
		return $result;
	}

	// извлечь идентификатор следующего вопроса и сам вопрос по данному идентификатору теста
	function get_id_and_question_by_id_test($link, $id_test, $numprevquest)
	{
		$query = "SELECT id_question, question FROM questions WHERE id_question IN (SELECT min(id_question) FROM questions WHERE id_test='$id_test' AND id_question > '$numprevquest')";
		$result  = mysqli_query($link, $query) or die(mysqli_error($link));
		return $result;
	}

	// извлечь идентификатор следующего ответа и сам ответ по данному идентификатору вопроса
	function get_id_and_answer_and_trueanswer_by_id_question($link, $id_question, $idprevanswer)
	{
		$query = "SELECT id_answer, answer, true_answer FROM answers WHERE id_answer IN (SELECT min(id_answer) FROM answers WHERE id_question='$id_question' AND id_answer > '$idprevanswer')";
		$result  = mysqli_query($link, $query) or die(mysqli_error($link));
		return $result;
	}

	// извлечь идентификатор последнего вопроса по идентификатору данного теста
	function get_id_lastquest_by_id_test($link, $id_test)
	{
		$query = "SELECT id_question FROM questions WHERE id_test='$id_test' ORDER BY id_question DESC LIMIT 1";
		$result  = mysqli_query($link, $query) or die(mysqli_error($link));
		return $result;
	}

	// количество вопросов по данному тесту
	function numquestions_by_id_test($link, $id_test)
	{
		$query = "SELECT COUNT(*) FROM questions WHERE id_test='$id_test'";
		$result  = mysqli_query($link, $query) or die(mysqli_error($link));
		return $result;
	}
?>
