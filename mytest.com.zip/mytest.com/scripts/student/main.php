<?php
  session_start();
  if (!isset($_SESSION['login']))
  {
    Header("Location: /index.php");
  }
?>
<!DOCTYPE html>
<html>
	<head>
		<title> Тестирование </title>
		<link rel="stylesheet" type="text/css" href="/style.css">
 	</head>
	<body> 
  	<p class="main_header">Система тестирования "Take the test"</p>
 		<p class="main_text"><?php echo("Добро пожаловать, ".$_SESSION['login']."!"); ?></p>
  	<form method="post" action="choose_test.php">
  	<table border="0" cellspacing="7" cellpadding="0"> 
    	<tr> 
      	<td class="spisok">Выберите категорию теста: </td>
      	<td>
					<?php
						require_once("queries.php");
						$query = get_categories($link);
						echo "<select name=\"category\">";
						while (list($category) = mysqli_fetch_row($query))
						{
							echo "<option>$category</option>";
						}
						echo "</select>";
					?>
				</td>
    	</tr>
   	</table></br>
   <table border="0" cellspacing="7" cellpadding="0" align="center"> 
  	<tr>
     	<td width="50"><input type="submit" name="submit" value="Далее"></input></td>
  	</tr>
  	</table>
  </form>
 </body>
</html>
