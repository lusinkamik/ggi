<?php
  session_start();
  if (!isset($_SESSION['login']))
  {
    Header("Location: /index.php");
  }
	require_once("queries.php");
	
	// задаем набор символов по умолчанию
	if (!mysqli_set_charset($link, "utf8"))
	{
		die("Ошибка при загрузке набора UTF8: " . mysqli_error($link) . "\n");
	}

	// экранируем специальные символы
	$name  = mysqli_real_escape_string($link, $_POST['name']);
	$theme = mysqli_real_escape_string($link, $_POST['theme']);
	$level = mysqli_real_escape_string($link, $_POST['level']);

	// определяем пустоту введенных данных
	if (!empty($name) && !empty($theme) && !empty($level))
	{

		// определяем номер категории теста по его названию
		$result = get_id_category_by_name($link, $name);
		$row = mysqli_fetch_row($result);
		mysqli_free_result($result);
		$id_category = (int) $row[0];

		// создаем новый тест
		if ($level == "1 уровень") {$level = 1;}
		if ($level == "2 уровень") {$level = 2;}
		if ($level == "3 уровень") {$level = 3;}
		create_test($link, $theme, $level, $id_category, (int) $_SESSION['id_user']);
	
		// занести в сессию идентификатор текущего теста
		$result = get_id_last_row_from_tests($link);
		$row = mysqli_fetch_row($result);
		mysqli_free_result($result);
		$id_test = (int) $row[0];
		$_SESSION['id_test'] = $id_test;

		Header("Location: question.php");
	}
	else Header("Location: new_test.php");
?>

