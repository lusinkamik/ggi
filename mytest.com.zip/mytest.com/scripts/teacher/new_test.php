<?php
  session_start();
  if (!isset($_SESSION['login']))
  {
    Header("Location: /index.php");
  }
?>
<!DOCTYPE html>
<html>
	<head>
		<title> Тестирование </title>
		<link rel="stylesheet" type="text/css" href="/style.css">
 	</head>
	<body> 
  	<p class="main_header">Система тестирования "Take the test"</p>
 		<p class="main_text"><?php echo("Добро пожаловать, ".$_SESSION['login']."!"); ?></p>
  	<form method="post" action="create_test.php">
  	<table border="0" cellspacing="7" cellpadding="0"> 
    	<tr> 
      	<td class="spisok">Выберите категорию теста: </td>
      	<td>
		<?php
						require_once("queries.php");
						$query = get_categories($link);
						echo "<select name=\"name\">";
						while (list($catname) = mysqli_fetch_row($query))
						{
							echo "<option>$catname</option>";
						}
						echo "</select>";
					?>
				</td>
    	</tr>
    	<tr>
      	<td class="spisok">Введите название теста: </td>
      	<td><input type="text" name="theme" maxlength="1024" size="120"></input> </td>
    	</tr>
    	<tr>
      	<td class="spisok">Выберите уровень сложности: </td>
      	<td>
		<select name="level">
			<option>1 уровень</option>
			<option>2 уровень</option>
			<option>3 уровень</option>
		</select>
	 </td>
    	</tr>
   	</table></br>
   <table border="0" cellspacing="7" cellpadding="0" align="center"> 
  	<tr>
     	<td width="50"><input type="submit" name="submit" value="Создать тест"></input></td>
  	</tr>
  	</table>
  </form>
 </body>
</html>
