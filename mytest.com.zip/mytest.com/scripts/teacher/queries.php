<?php
	// подключение к БД от имени teacher
	require_once("connect.php");
	// задаем глобально кодировку для БД
	mysqli_query($link, 'SET NAMES utf8');
	// выбрать все категории
	function get_categories($link)
	{
		$query = "SELECT name FROM categories";
		$result = mysqli_query($link, $query) or die(mysqli_error($link));
		return $result;
	}

	// извлечь номер категории теста по категории теста
	function get_id_category_by_name($link, $name)
	{
		$query = "SELECT (id_category) FROM categories WHERE name='$name'";
		$result  = mysqli_query($link, $query) or die(mysqli_error($link));
		return $result;
	}

	// создать новый тест
	function create_test($link, $theme, $level, $id_category, $id_user)
	{
		$curdate = date("Y-m-d");
		$query   = "INSERT INTO tests (theme, pubdate, level, id_category, id_user) VALUES ('$theme', '$curdate', '$level', '$id_category', '$id_user')";
		$result  = mysqli_query($link, $query) or die(mysqli_error($link));
	}

	// добавить вопрос в БД
	function add_question($link, $question, $id_test)
	{
		$query = "INSERT INTO questions (question, id_test) VALUES ('$question', '$id_test')";
		$result  = mysqli_query($link, $query) or die(mysqli_error($link));
	}
	
	// извлечь идентификатор последней записи из таблицы tests
	function get_id_last_row_from_tests($link)
	{
		$query = "SELECT (id_test) FROM tests ORDER BY id_test DESC LIMIT 1";
		$result  = mysqli_query($link, $query) or die(mysqli_error($link));
		return $result;
	}
	
	// извлечь идентификатор последней записи из таблицы questions
	function get_id_last_row_from_questions($link)
	{
		$query = "SELECT (id_question) FROM questions ORDER BY id_question DESC LIMIT 1";
		$result  = mysqli_query($link, $query) or die(mysqli_error($link));
		return $result;
	}

	// добавить один ответ по текущему вопросу в БД
	function add_answer($link, $answer, $true_answer, $id_question)
	{
		$query = "INSERT INTO answers (answer, true_answer, id_question) VALUES ('$answer', '$true_answer', '$id_question')";
		$result  = mysqli_query($link, $query) or die(mysqli_error($link));
	}
?>
