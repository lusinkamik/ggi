<?php
  session_start();
  if (!isset($_SESSION['login']))
  {
    Header("Location: /index.php");
  }
?>

<!DOCTYPE html>
<html>
	<head>
		<title> Тестирование </title>	
		<link rel="stylesheet" type="text/css" href="/style.css">
 	</head>
	<body> 
  	<p class="main_header">Система тестирования "Take the test"</p>
		<table width="100%" border="0">
 			<tr>
				<td><p class="main_text"><?php echo("Режим создания теста:"); ?></p></td>
				<td><a id="logout" href="logout.php">Завершить</td>
			</tr>
		</table>
  	<form method="post" action="add_question.php">
  	<table border="0" cellspacing="7" cellpadding="0"> 
    	<tr>
      	<td class="spisok">Введите вопрос: </td>
      	<td><input type="text" name="question" maxlength="1024" size="80"></input> </td>
    	</tr>
    	<tr>
    		<td align="right"><input type="radio" name="radio" value="1" checked="checked"></input></td>
      	<td><input type="text" name="answer1" maxlength="1024" size="50"></input></td>
    	</tr>
    	<tr>
      	<td align="right"><input type="radio" name="radio" value="2"></input></td>
      	<td><input type="text" name="answer2" maxlength="1024" size="50"></input></td>
    	</tr>
    	<tr>
      	<td align="right"><input type="radio" name="radio" value="3"></input></td>
      	<td><input type="text" name="answer3" maxlength="1024" size="50"></input></td>
    	</tr>
    	<tr>
      	<td align="right"><input type="radio" name="radio" value="4"></input></td>
      	<td><input type="text" name="answer4" maxlength="1024" size="50"></input></td>
   		</tr>
   	</table></br>
   <table border="0" cellspacing="7" cellpadding="0" align="center"> 
  	<tr>
    	<td width="50"><input type="submit" name="submit" value="Внести вопрос"></input></td>
  	</tr>
  	</table> 
  </form>  
 </body>
</html>
