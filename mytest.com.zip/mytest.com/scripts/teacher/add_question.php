<?php
  session_start();
  if (!isset($_SESSION['login']))
  {
    Header("Location: /index.php");
  }
	require_once("queries.php");
	
	// задаем набор символов по умолчанию
	if (!mysqli_set_charset($link, "utf8"))
	{
		die("Ошибка при загрузке набора UTF8: " . mysqli_error($link) . "\n");
	}

	// экранируем специальные символы
	$question    = mysqli_real_escape_string($link, $_POST['question']);
	$corr_answer = mysqli_real_escape_string($link, $_POST['radio']);
	$answers     = array(mysqli_real_escape_string($link, $_POST['answer1']),
	                     mysqli_real_escape_string($link, $_POST['answer2']),
	                     mysqli_real_escape_string($link, $_POST['answer3']),
	                     mysqli_real_escape_string($link, $_POST['answer4']));

	// проверка введенных данных на пустоту
	if (!empty($question) && !empty($corr_answer) && !empty($answers[0]) && 
			!empty($answers[1]) && !empty($answers[2]) && !empty($answers[3]))
	{

		// заносим вопрос в БД
		$id_test = $_SESSION['id_test'];
		add_question($link, $question, $id_test);
	
		// вытаскиваем идентификатор текущего вопроса
		$result = get_id_last_row_from_questions($link);
		$row = mysqli_fetch_row($result);
		mysqli_free_result($result);
		$id_question = (int) $row[0];

		// заносим ответы по данному вопросу в БД
		$i = 1;
		foreach ($answers as $answer)
		{
			if ($i == (int) $corr_answer) $true_answer = 1;
			else $true_answer = 0; $i++;
			add_answer($link, $answer, $true_answer, $id_question);
		}
	}
	// в любом случае возвращаемся на страницу добавления вопроса
	Header("Location: question.php")
?>

