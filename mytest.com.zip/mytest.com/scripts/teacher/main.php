<?php
  session_start();
  if (!isset($_SESSION['login']))
  {
    Header("Location: /index.php");
  }
?>

<!DOCTYPE html>
<html>
	<head>
		<title> Тестирование </title>
 		<link rel="stylesheet" type="text/css" href="/style.css">
	</head>
	<body> 
  	<p class="main_header">Система тестирования "Take the test"</p>
  	<a class="new_test"  href="new_test.php"> создать тест</a>
  	<a class="del_test" href="del_test.php"> удалить тест</a>
  </body>
</html>
