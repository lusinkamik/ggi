<?php
  session_start();
	$_SESSION = array();
	session_destroy();
	session_start();
  if (!empty($_POST ['login']) && !empty($_POST['passwd']))
  {
    // подключение к базе данных от имени пользователя user
		require_once("connect.php");
		
		// задаём набор символов по умолчанию
    if (!mysqli_set_charset($link, "utf8"))
		{
			die("Ошибка при загрузке набора utf8: " . mysqli_error($link) . "\n");
		}

		// экранируем специальные символы
    $login  = mysqli_real_escape_string($link, $_POST['login']);
  	$passwd = mysqli_real_escape_string($link, $_POST['passwd']);     

		// запрос на выборку
		$query = "SELECT pass,id_user,id_user_group FROM users WHERE login='$login'";
		$result = mysqli_query($link, $query) or die(mysqli_error($link));
		$row = mysqli_fetch_row($result);
		mysqli_free_result($result);
		mysqli_close($link);
		if (!empty($row))
		{
			if ($row[0] == md5($passwd))
			{
				$_SESSION['login'] = $login;
				$_SESSION['id_user'] = $row[1];
				if ($row[2] == '1')
				{
					Header("Location: /scripts/teacher/main.php");
				}
				if ($row[2] == '2')
				{
					Header("Location: /scripts/student/main.php");
				}
			}
			else
			{
				die("Неверные данные аутентификации\n");
			}
		}
		else
		{
			die("Неверные данные аутентификации\n");
		}
  }
  else
  {
		Header("Location: /index.php");
  }
?>
